<?php
/**
 * Created by PhpStorm.
 * User: efadmin
 * Date: 03.12.18
 * Time: 15:43
 */

// Eine Variable deklarieren ,
// die zur Ausgabe der Daten auf der Webseite dient
$resultate = "\n<table >\n";
try {
// Ein PDO - Objekt erzeugen und der Variable $dbHandler zuweisen :
    $dbHandler = new PDO('mysql:host=localhost;dbname=uebungsdb;charset=utf8',
        'efadmin',
        'efadmin');
// Dafuer sorgen , dass das PDO - Objekt " Exceptions wirft" ( siehe Tutorial !)
    $dbHandler->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    print("<h3 >Fehler bei der DB -Verbindung </h3 >");
    print ("<p>" . $e->getMessage() . " </p>");
}
// Das SQL - Suchstatement formulieren und einer Variable zuweisen :
$alleSchuelerSQL = "
SELECT p_vorname , p_name , p_email
FROM person
WHERE rolle_rol_ID = 1
ORDER BY p_vorname ASC";
try {

// Ein PDO -Statement - Objekt erzeugen :
    $stmt = $dbHandler->prepare($alleSchuelerSQL);
// Fuer jedes Attribut der gefundenen Datensaetze eine
// Variable vorbereiten :
    $stmt->bindColumn('p_vorname', $vorname);
    $stmt->bindColumn('p_name', $name);
    $stmt->bindColumn('p_email', $email);
// Das Statement ausfuehren lassen :
    $stmt->execute();
// In einer Schleife Zeile fuer Zeile der Resultate - Tabelle
// auslesen . Die Werte sind jetzt ueber die oben definierten Variablen
// verfuegbar .
    while ($stmt->fetch()) {
        $resultate .= "<tr >\n<td >$vorname </td ><td >$name </td ><td >$email </td >\n </tr >";
    }
// Die DB - Verbindung wieder freigeben
    $stmt->closeCursor();
} catch (PDOException $e) {
    $resultate .= ("<h3 > Fehler bei der DB - Verbindung !</h3 >\n");
    $resultate .= ("<p> Fehlermeldung des DB - Servers :</p >\n");
    $resultate .= ("<p>" . $e->getMessage() . " </p>\n");
    $resultate .= ("<h4 >Stack -Trace </h4 >\n");
    $resultate .= ($e->getTraceAsString());
}
?>

<! DOCTYPE html >
<html>
<head>
    <meta charset="utf-8">
    <title>Alle Sch&uuml;lerinnen und Sch&uuml;ler </title >
    <style>
        table, tr, td {
            border: 1px solid black;
            border -collapse: collapse;
        }
    </style>
</head>
<body>
<h1>Alle Sch&uuml;lerInnen des EF Informatik 14/15 </h1>
<?php
// Hier geben wir nur noch den Inhalt der Variable $resultate aus:
print($resultate);
?>
</body>
</html>